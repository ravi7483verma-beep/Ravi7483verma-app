package com.ravi7483verma.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContent { RaviApp() } }
}

@Composable fun RaviApp() {
    var loggedIn by remember { mutableStateOf(false) }
    var register by remember { mutableStateOf(false) }
    if (!loggedIn) AuthScreen(register, { register = false; loggedIn = true }, { register = !register })
    else MainScreen { loggedIn = false }
}

@Composable fun AuthScreen(register: Boolean, onLogin: () -> Unit, onToggle: () -> Unit) {
    var user by remember { mutableStateOf("") }; var pass by remember { mutableStateOf("") }; var name by remember { mutableStateOf("") }
    Surface(Modifier.fillMaxSize()) { Column(Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Text("Ravi7483verma", fontSize = 32.sp, fontWeight = FontWeight.Bold)
        Text(if (register) "Create your account" else "Welcome back", color = Color.Gray, modifier = Modifier.padding(bottom = 24.dp))
        if (register) OutlinedTextField(name, { name = it }, label = { Text("Name") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(user, { user = it }, label = { Text("User ID / Email / Mobile") }, modifier = Modifier.fillMaxWidth().padding(top = 10.dp))
        OutlinedTextField(pass, { pass = it }, label = { Text("Password") }, modifier = Modifier.fillMaxWidth().padding(top = 10.dp))
        if (register) OutlinedTextField("", {}, label = { Text("Confirm Password") }, modifier = Modifier.fillMaxWidth().padding(top = 10.dp))
        Button(onClick = onLogin, modifier = Modifier.fillMaxWidth().padding(top = 18.dp)) { Text(if (register) "Create Account" else "Login") }
        if (!register) TextButton(onClick = {}) { Text("Forgot Password?") }
        TextButton(onClick = onToggle) { Text(if (register) "Already have an account? Login" else "Create a new account") }
    }}
}

@Composable fun MainScreen(onLogout: () -> Unit) {
    var tab by remember { mutableIntStateOf(0) }
    Scaffold(bottomBar = { NavigationBar { listOf("Home","Search","Post","Alerts","Profile").forEachIndexed { i, label -> NavigationBarItem(selected = tab == i, onClick = { tab = i }, icon = { Text(listOf("⌂","⌕","＋","♡","○")[i], fontSize = 22.sp) }, label = { Text(label) }) } } }) { p ->
        when (tab) { 0 -> Feed(Modifier.padding(p)); 4 -> Profile(Modifier.padding(p), onLogout); else -> Placeholder(label = listOf("Home","Search","Post","Alerts","Profile")[tab], modifier = Modifier.padding(p)) }
    }
}

@Composable fun Feed(modifier: Modifier = Modifier) {
    val posts = listOf("Ravi7483verma", "Ravi Verma", "Ravi7483")
    LazyColumn(modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item { Text("Ravi7483verma", fontSize = 25.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(8.dp)) }
        items(posts) { user -> Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) { Column(Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) { Box(Modifier.size(42.dp).clip(CircleShape).background(Color.LightGray)); Text(user, fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 10.dp)) }
            Box(Modifier.fillMaxWidth().height(220.dp).padding(top = 12.dp).clip(RoundedCornerShape(12.dp)).background(Color(0xFFE8E8E8)), contentAlignment = Alignment.Center) { Text("Photo / Video", color = Color.Gray) }
            Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(18.dp)) { Text("♡ Like"); Text("💬 Comment"); Text("↗ Share") }
            Text("यह Ravi7483verma का demo post है।", modifier = Modifier.padding(top = 8.dp))
        } } }
    }
}

@Composable fun Profile(modifier: Modifier = Modifier, onLogout: () -> Unit) {
    Column(modifier.fillMaxSize().padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.size(100.dp).clip(CircleShape).background(Color.LightGray), contentAlignment = Alignment.Center) { Text("RV", fontSize = 28.sp, fontWeight = FontWeight.Bold) }
        Text("Ravi7483verma", fontSize = 24.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 12.dp))
        Text("Ravi Verma", color = Color.Gray); Text("0 Posts   0 Followers   0 Following", modifier = Modifier.padding(16.dp))
        OutlinedButton(onClick = {}, Modifier.fillMaxWidth()) { Text("Edit Profile") }
        OutlinedButton(onClick = onLogout, Modifier.fillMaxWidth().padding(top = 8.dp)) { Text("Logout") }
    }
}

@Composable fun Placeholder(label: String, modifier: Modifier = Modifier) { Box(modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text(label, fontSize = 26.sp, fontWeight = FontWeight.Bold) } }
